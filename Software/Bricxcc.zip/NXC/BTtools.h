
//
//    BTtools.h
//    data exchange functions using bluetooth
//    based on BTLib by Daniele Benedettelli
//    modified from http://www.alfonsomartone.itb.it/yepuji.html

#ifndef CHANNEL
#define CHANNEL   1    // slave channel can be 1, 2 or 3
#endif

#define MASTER    0    // master channel is always 0


byte __local_buffer[80];
byte __local_array[59];

void btwaitfor(int conn)
{
  byte e=NO_ERR+1;
  while(e!=NO_ERR)
  {
    e=BluetoothStatus(conn);

    if(e==NO_ERR) break;
    if(e==STAT_COMM_PENDING) continue;

   TextOut(0, LCD_LINE2, "Bluetooth error:", true);
   NumOut(30, LCD_LINE4, e);

   switch(e)
   {
     case ERR_COMM_CHAN_NOT_READY:
          TextOut(0, LCD_LINE6, "NXT bluetooth");
          TextOut(0, LCD_LINE7, "not connected!");
          break;

     case ERR_COMM_BUS_ERR:
          TextOut(0, LCD_LINE6, "bus error:");
          TextOut(0, LCD_LINE7, "please reboot");
          break;
    }
    Wait(7000);
    Stop(true);
  }
}


void sendtomaster(string msg, byte mbx = 0)
{
  //btwaitfor(MASTER);
  if(mbx < 9) mbx += 10;
  SendMessage(mbx, msg);
  //btwaitfor(MASTER);
}


void sendtoslave(string msg, byte mbx = 0)
{
  byte len;
  int i;

  StrToByteArray(msg,__local_array);
  len = ArrayLen(__local_array);
  __local_buffer[0] = 0x80;    // no reply telegram
  __local_buffer[1] = 0x09;    // MessageWrite Direct Command
  __local_buffer[2] = mbx; // mailbox number
  __local_buffer[3] = len+1;   // message size

  len=len+4;
  i=4;
  for(;;)
  {
    __local_buffer[i] = __local_array[i-4];
    i++;
    if(i>=len) break;
  }

  btwaitfor(CHANNEL);
  BluetoothWrite(CHANNEL, __local_buffer);
  btwaitfor(CHANNEL);
}


string receivefrommaster(byte mbx = 0)
{
  string msg;
  //btwaitfor(MASTER);
  ReceiveMessage(mbx, true, msg);
  //btwaitfor(MASTER);
  return msg;
}


string receivefromslave(byte mbx = 0)
{
  string msg;
  btwaitfor(CHANNEL);
  ReceiveMessage(mbx, true, msg);
  btwaitfor(CHANNEL);
  return msg;
}


void btchannelcheck(int conn)
{
  int e = BluetoothStatus(conn);
  string m;

  if(e==NO_ERR) return;

  TextOut(0, LCD_LINE3, "Bluetooth error", true);
  NumOut(0,  LCD_LINE4, e);
  TextOut(0, LCD_LINE8, "on channel -.");
  NumOut(66, LCD_LINE8, conn);

  if(conn==CHANNEL)
  {
    TextOut(0, LCD_LINE1, "Master NXT");
    TextOut(0, LCD_LINE6, "please connect");
    TextOut(0, LCD_LINE7, "the slave NXT");
  }
  else
  {
    TextOut(0, LCD_LINE1, "Slave NXT");
    TextOut(0, LCD_LINE6, "please wait for");
    TextOut(0, LCD_LINE7, "the master NXT");
  }
  for(int i; i <10; i++){
    PlayTone(440, 500);
    Wait(1000);
  }
  Stop(true);
}

void BTconnect(byte conn, string name){
  if(BluetoothStatus(conn)!= NO_ERR){//skip if connected already
    CommBTConnectionType args;
    args.ConnectionSlot = conn;
    args.Name = name;
    args.Action = true;
    SysCommBTConnection(args);
    until(BluetoothStatus(1) == NO_ERR);
  }
  PlayToneEx(440, 250, 2, false); Wait(250);
  RemotePlayTone(1, 440, 250); Wait(250);
}
// -- convenience functions --

void mastercheck()  { btchannelcheck(CHANNEL); }
void slavecheck()   { btchannelcheck(MASTER);  }


// --- end ---
