***********************************************************************
* Source code for Creating Cool MINDSTORMS NXT Robots (1-59059-966-7) *
* Copyright 2008 by Daniele Benedettelli                              *
***********************************************************************

Each folder contains the NXC programs source code.
To use the code, simply open the NXC files in the BricxCC IDE, 
compile and download the program to NXT.
In the Chapter02 folder you find also the NXT-G program for Quasimodo.

In some folders you might find the RSO sound effect files for the robots.
Download them using the NXT Explorer utility of BricxCC to let the NXT play them.

04/04/2008

11/05/2008
Fixed old references in JohnNXT source code.
Added the missing file "autoconnect.nxc".